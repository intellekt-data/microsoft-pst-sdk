#ifndef TEST_H
#define TEST_H

void test_util();
void test_btree();
void test_db();
void test_disk();
void test_highlevel();
void test_pstlevel();

#endif

