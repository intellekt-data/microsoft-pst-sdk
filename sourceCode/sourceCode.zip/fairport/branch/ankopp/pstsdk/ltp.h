//! \defgroup ltp LTP Layer
#ifndef PSTSDK_LTP_H
#define PSTSDK_LTP_H

#include "pstsdk/ltp/heap.h"
#include "pstsdk/ltp/object.h"
#include "pstsdk/ltp/propbag.h"
#include "pstsdk/ltp/table.h"
#include "pstsdk/ltp/nameid.h"

#endif
