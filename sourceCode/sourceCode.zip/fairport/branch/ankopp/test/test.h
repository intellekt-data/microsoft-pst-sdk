#ifndef TEST_H
#define TEST_H

void test_util();
void test_btree();
void test_db();
void test_disk();
void test_highlevel();
void test_pstlevel();
void test_subnode();
void test_btpage();
void test_amap();
void test_node_save();
void test_db_context();
void test_thread_safety();
void test_heap_node();
void test_bth();
void test_pc();
void test_tc();
void test_pst();
#endif

